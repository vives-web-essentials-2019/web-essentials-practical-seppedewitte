# Report

**Name**: <!-- TODO: fill in your full name here, firstname and lastname -->

---

<!-- Fill out all the questions below by replacing the TODO comments. Do not remove the other markdown. Make sure to answer EACH question. -->

**What is working and what is not?**

<!-- TODO: Fill out this question -->

**Was the assignment to hard or to easy? What was too hard or what was too easy**

<!-- TODO: Fill out this question -->

**For what part of the assignment did you need to do some research? (for example Google search)**

<!-- TODO: Fill out this question -->

**How much time did you approximately spend on this assignment (excluding time of report)?**

<!-- TODO: Fill out this question -->

**Is there any code you copied from someone else or from the Internet? Provide the source here (author, website, ...). Also explain what you changed to the source code.**

<!-- TODO: Fill out this question -->

**Is there a piece of code that you are not satisfied with. Place it here and describe what you think is wrong with it.**

<!-- TODO: Fill out this question -->

## Need to knows and remarks

<!--
Here you should place extra remarks that the teacher needs to know to get the solution working. For example if one needs to change some configuration file or install some extra libraries or whatever. There is also room for extra remarks you would like to make that you were not able to fit inside one of the sections above.
-->