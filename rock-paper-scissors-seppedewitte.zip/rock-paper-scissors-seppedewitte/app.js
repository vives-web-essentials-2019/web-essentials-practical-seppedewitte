
/*const game = () => {
  let playerScore = 0;
  let computerScore = 0;

    //Computer Options
    const computerOptions = ["rock", "paper", "scissors"];

    options.forEach(option => {
      option.addEventListener("click", function() {
        //Computer Choice
        const computerNumber = Math.floor(Math.random() * 3);
        const computerChoice = computerOptions[computerNumber];

        setTimeout(() => {
          //Here is where we call compare hands
          compareHands(this.textContent, computerChoice);
          //Update Images
          playerHand.src = //hier png insteken`./assets/${this.textContent}.png`;
          computerHand.src = //hier png insteken`./assets/${computerChoice}.png`;
        }, 2000);
        
      });
    });
  };

  const updateScore = () => {
    const playerScore = document.querySelector(".player-score p");
    const computerScore = document.querySelector(".computer-score p");
    playerScore.textContent = pScore;
    computerScore.textContent = cScore;
  };

  const compareHands = (playerChoice, computerChoice) => {
    //Update Text
    const winner = document.querySelector(".winner");
    //tie
    if (playerChoice === computerChoice) {
      winner.textContent = "It is a tie";
      return;
    }
    //Rock
    if (playerChoice === "rock") {
      if (computerChoice === "scissors") {
        winner.textContent = "Player Wins";
        playerScore = playerScore + 1 ;
        updateScore();
        return;
      } else {
        winner.textContent = "Computer Wins";
        computerScore = computerScore + 1 ;
        updateScore();
        return;
      }
    }
    //paper
    if (playerChoice === "paper") {
      if (computerChoice === "scissors") {
        winner.textContent = "Computer Wins";
        computerScore = computerScore + 1 ;
        updateScore();
        return;
      } else {
        winner.textContent = "Player Wins";
        playerScore = playerScore + 1 ;
        updateScore();
        return;
      }
    }
    //Scissors
    if (playerChoice === "scissors") {
      if (computerChoice === "rock") {
        winner.textContent = "Computer Wins";
        computerScore = computerScore + 1 ;
        updateScore();
        return;
      } else {
        winner.textContent = "Player Wins";
        playerScore = playerScore + 1 ;
        updateScore();
        return;
      }
    }
  };

  //Is call all the inner function
  startGame();
  playMatch();
};

//start the game function
game();
*/